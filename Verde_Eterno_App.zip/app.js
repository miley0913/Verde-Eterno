
let plantas = [];

window.onload = async () => {
  const res = await fetch('plantas_completas.json');
  plantas = await res.json();
  mostrarPlantas(plantas);
};

function iniciarSesion() {
  const username = document.getElementById("username-input").value;
  document.getElementById("saludo").innerText = `Bienvenido, ${username}`;
  document.getElementById("login-screen").style.display = "none";
  document.getElementById("app-content").style.display = "block";
}

function cerrarSesion() {
  document.getElementById("login-screen").style.display = "block";
  document.getElementById("app-content").style.display = "none";
}

function mostrarPlantas(lista) {
  const contenedor = document.getElementById("plant-list");
  contenedor.innerHTML = "";
  lista.forEach(p => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h3>${p.name}</h3>
      <img src="${p.img}" alt="${p.name}">
      <p><strong>Nombre científico:</strong> ${p.scientific}</p>
      <p><strong>Origen:</strong> ${p.from}</p>
      <p><strong>Tipo:</strong> ${p.type}</p>
      <p><strong>Usos:</strong> ${p.uses}</p>
      <p><strong>Cómo usarla:</strong> ${p.howToUse || 'No especificado'}</p>
    `;
    contenedor.appendChild(card);
  });
}

function buscarPorSintoma() {
  const valor = document.getElementById("search").value.toLowerCase();
  const resultado = plantas.filter(p => p.uses.toLowerCase().includes(valor) || p.name.toLowerCase().includes(valor));
  mostrarPlantas(resultado);
}

function filterByType(tipo) {
  if (tipo === 'all') {
    mostrarPlantas(plantas);
  } else {
    const filtradas = plantas.filter(p => p.type.toLowerCase().includes(tipo));
    mostrarPlantas(filtradas);
  }
}
